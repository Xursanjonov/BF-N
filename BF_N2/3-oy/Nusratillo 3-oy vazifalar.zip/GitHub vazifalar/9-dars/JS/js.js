let translate = {
  olma: { uzb: "olma", eng: "Apple" },
  tarvuz: { uzb: "Tarvuz", eng: "Watermelon" },
  banan: { uzb: "Banan", eng: "Banana" },
  uzum: { uzb: "Uzum", eng: "Grapes" },
  gilos: { uzb: "Gilos", eng: "Cherry" },
  ananas: { uzb: "Ananas", eng: "Pineapple" },
  apelsin: { uzb: "apelsin", eng: "Orange" },
  shaptoli: { uzb: "shaftoli", eng: "Peach" },
};

function translate(fruit, language) {
    if (translate[fruit]) {
        return translate[fruit][language];
    } else {
        console.log("There is no such word.!")
    }
}


// number Game
const n = Math.floor(Math.random() * 20) + 1;
console.log(n)
let chanc = 5;

function numberGames() {
  while (chanc > 0) {
    let userGuess = parseInt(prompt("1 dan 20 gacha son yozing: "));

    if (userGuess === n) { console.log("Topdingiz qoyil."); return; }
    else { chanc--; console.log(chanc + "ta urinishingiz qoldi"); }
  }
  console.log("O'yin tugadi, Topa olmadingiz, raqam " + n + " edi");
}

numberGames();

