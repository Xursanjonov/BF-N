// { ENG } Uyga vazifa
// 1) Taymer (orqaga sanash) 

let input = document.querySelector(".input");
let day = document.querySelector(".day");
let hour = document.querySelector(".hour");
let minute = document.querySelector(".minute");
let second = document.querySelector(".second");
let pmam = document.querySelector(".pmam");

function dsTimes(){
    let now = new Date();

    let hours = now.getHours();
    let minutes = now.getMinutes();
    let seconds = now.getSeconds();

    hour.innerHTML = hours.toString(10).padStart(2, "0");
    minute.innerHTML = minutes.toString(10).padStart(2, "0");
    second.innerHTML = seconds.toString(10).padStart(2, "0");
}

dsTimes();
setInterval(dsTimes, 1000);

function dsPMAM(){
    let now = new Date();

    let hours = now.getHours();

    let pmams = "";

    if(hours < 12){
        pmams = "A.M.";
    } else {
        pmams = "P.M.";
    }
    pmam.innerHTML = pmams;
}

dsPMAM();
setInterval(dsPMAM, 360000);

(function (){
    let now = new Date();

    let date = now.getDate().toString(10).padStart(2, "0");
    day.innerHTML = date;
})();


// 2) Sehrli 8 ball ( ● Bu aniq ● Bu aniq ● Shubhasiz ● Ha, albatta ● Bunga ishonishingiz mumkin ● Ko'rib turganimdek, ha ● Katta ehtimol bilan ● Outlook yaxshi ● Ha ● Ishoralar “Ha”ga ishora qiladi ● Javob noaniq, qayta urinib ko‘ring ● Keyinroq qayta so‘rang ● Hozir aytmagan ma’qul ● Hozir bashorat qilib bo‘lmaydi ● Diqqatni jamlab, qayta so‘rang ● Unga ishonmang ● Mening javobim “yo‘q” ● Mening manbalarim “yo‘q” deyapti ● Outlook yo‘q juda yaxshi ● Juda shubhali )

// 3) Yopishqoq eslatma generatori

// 4) So‘zni taxmin qiling (5 imkoniyat) (https://res.cloudinary.com/practicaldev/image/fetch/s--8hKgOu9x--/c_limit%2Cf_auto%2Cfl_progressive% 2Cq_auto%2Cw_880/https://dev-to-uploads.s3.amazonaws.com/uploads/articles/tf405aexymb4io1tubdw.png) 

// 5?) Pitsa tayyorlovchi (https://cdn.akamai.steamstatic.com/steam/apps/ 851330/ss_846d6a8f25e1396e6c545165ab0bd58bfa41d37f.1920x1080.jpg?t=1583417623)

// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

// { ENG } Uyga vazifa
// 1) Timer (count down)

// 2) Magic 8 ball ( ● It is certain ● It is decidedly so ● Without a doubt ● Yes definitely ● You may rely on it ● As I see it, yes ● Most likely ● Outlook good ● Yes ● Signs point to yes ● Reply hazy, try again ● Ask again later ● Better not tell you now ● Cannot predict now ● Concentrate and ask again ● Don't count on it ● My reply is no ● My sources say no ● Outlook not so good ● Very doubtful )

// 3) Sticky note generator

// 4) Guess the word (5 chances) (https://res.cloudinary.com/practicaldev/image/fetch/s--8hKgOu9x--/c_limit%2Cf_auto%2Cfl_progressive%2Cq_auto%2Cw_880/https://dev-to-uploads.s3.amazonaws.com/uploads/articles/tf405aexymb4io1tubdw.png)

// 5?) Pizza maker (https://cdn.akamai.steamstatic.com/steam/apps/851330/ss_846d6a8f25e1396e6c545165ab0bd58bfa41d37f.1920x1080.jpg?t=1583417623)
