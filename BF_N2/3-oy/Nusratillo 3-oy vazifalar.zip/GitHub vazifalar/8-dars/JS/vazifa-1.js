// 1) Reverse string => "Lorem" -> "meroL" (For, prompt)

let str = prompt("Nimadir yozing: ");
let returnStr = ""

for (let i = str.length - 1; i >= 0; i--) {
    returnStr = returnStr + str[i]
}
console.log(returnStr)

// 2) Reverse number => 8658 -> 8568 -> (For, prompt) NUMBER

// let num = prompt("Son kiriting: ");
// let natija = "";

// for (let i = num.length - 1; i >= 0; i--) {
//     natija = natija + num[i]
// }
// console.log( + natija)

let nums = prompt("Son kiriting: ");
let a = nums
console.log(+(nums.split('').reverse().join('')) + ', '+a);

// 3) Toq yoki Juft => 10 -> 0 juft, 9 -> toq
// let numbers = prompt("1 ta son kiriting: ")

let n = +prompt("Son kiritng: ");

if (n > 0) {
    for (let i = 0; i < n + 1; i++) {
        if (i % 2 === 0) {
            console.log(i + " Juft son")
        } else {
            console.log(i + " Toq son")
        }
    }
} else {
    console.log("Son kiriting!")
}


// while(true){
//     if(numbers % 2 === 0){ console.log(numbers+ ', '+ 'Juft'); break; }
// else if(numbers % 2 !== 0){ console.log(numbers+ ', '+ 'Toq'); break; }
// }

// 4) Tub sonmi ?
let tub = prompt("1 ta son kiriting: ");
let bool = true
for(let b = +prompt('Raqam kriting: '); bool; b++){
    bool = true;
    for (let c = 2; c < b; c++) {
        if (b % c === 0){
            console.log(c, b, true);
            bool = false;
            break;
        } else if(b % c === 1){
            console.log(c, b, false);
            bool = true;
            break;
        }
    }
    if(bool == true){
        console.log(b+ ', Tub son');
    } else if(tub == false){
        console.log(b+ ', Murakkab son');
    }
    bool = false
}

let number = +prompt("Bir son kiriting: ");
let sum = 1;

if (number <= 1) {
  console.log("Natural son");
} else {
  for (let i = 2; i <= number / 2; i++) {
    if (number % i === 0) {
      sum = sum + i;
    }
  }

  if (number === sum) {
    console.log("Mukammal Son")
  } else {
    console.log("Natural Son")
  }
}

