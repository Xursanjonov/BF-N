let age = +prompt("How old are you ?");
alert((2023 - age) + " yilda tug`ilgansiz");
let years = +prompt("Yil kiriting: ");
alert("Siz " + years +" yildan so'ng " + ((years - 2023) + age) + " yoshda bo'lasiz");