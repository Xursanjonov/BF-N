let arr = ["olma", "nok", "anor", "behi", "gilos"];

// 1-sharti => Keraksiz mevani kiriting
let keraksiz = prompt("keraksiz mevani kiriting: ");
arr.splice(arr.indexOf(keraksiz), 1);
console.log(arr);

// 2-sharti => Qaysi mevani qo'shmoqchisiz va Qaysi indexdan qo'shmoqchisiz
let kerakli = prompt("Qaysi mevani qo'shmoqchisiz: ");
let qayerdan = prompt("Qaysi indexdan qo'shmoqchisiz: ");
arr.splice(qayerdan, 0, kerakli);
console.log(arr);

// 2-sharti => Qaysi mevani o'zgartirmoqchisiz va Qaysi mevaga o'zgartirmoqchisiz
let unnecessary = prompt("qaysi mevani o'zgartirmoqchisiz: ");
let necessary__2 = prompt("qaysi mevaga o'zgartirmoqchisiz: ");
arr.splice(arr.indexOf(unnecessary), 1, necessary__2);
console.log(arr);