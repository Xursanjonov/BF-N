var son = prompt("Son kiriting: ") 
if (son === 0){
    console.log("Juft ham, Toq ham emas => ", son);
} else if (son % 2 === 0){
    console.log("Juft son => ", son);
} else if (son % 2 === 1){
    console.log("Toq son => ", son);
}

// let random = Math.random() * 10;
// console.log(+random.toFixed(2));


// Dollor and Europe kurs narxi
// let min = 12000;
// let max = 13000;

// let dollarKurs = Math.floor(Math.random() * (max - min + 1) + min);
// let euroKurs = Math.floor(Math.random() * (max - min + 1) + min);

// console.log(dollarKurs, euroKurs);