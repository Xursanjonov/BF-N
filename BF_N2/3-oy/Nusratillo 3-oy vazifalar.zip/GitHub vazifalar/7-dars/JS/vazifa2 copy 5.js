var n = prompt("1 ta son kiriting: ") 
if (n === 0){
    console.log("Musbat ham, Manfiy ham emas => ", n);
} else if (n > 0){
    console.log("Musbat son => ", n);
} else if (n < 0){
    console.log("Manfiy son => ", n);
}