let number = Math.floor(Math.random() * (30 - 20)) + 20;
let n = +prompt("20 - 30 oralig`ida son kiriting");
if (number === n) {
  console.log("To'g'ri topdingiz, Qoyilmaqom!");
} else {
  console.log("Topolmadingiz " + " O'ylangan son " + number + " kiritilgan son " + n);
}