let randoms = Math.random();
let colorwriting = randoms.toString(16);
let randomColor = colorwriting.slice(2, 8);

// console.log("#" + randomColor);
let color = ("#" + randomColor);
let div = document.querySelector("div");
div.textContent = color;
let body = document.querySelector("body");
body.style.backgroundColor = color;