let dolor = +prompt("Dollor kursi: ");
let euro = +prompt("Euro kursi: ");
let pul = +prompt("Pulingiz qancha ?");

let chipta = 350 * dolor;
let sayohat = 300 * euro;
let yashash = 500 * dolor;

let sum = chipta + yashash + sayohat;

if (sum > pul) {
  console.log(
    "Kechirasiz pulingiz yetarli emas."
  );
} else {
  console.log(
    "Safaringiz bexatar bo'lsin! Sizga xush kayfiyat va sog`lik tilaymiz"
  );
}