let piyoda = 500 / 2;
let velda = 500 / 20;
let moshinada = 500 / 70;
let poyezdda = 500 / 150;
let samalyotda = 500 / 880;

let ulov = prompt(
  "Quyidagilardan birini tanlang. Majburiy: 1)piyida, 2)velda, 3)moshinada, 4)poyezdda, 5)samalyotda"
);

switch (ulov) {
  case 1: { console.log("Andijnga Siz piyoda " + piyoda + " vaqtda Yetib borasiz"); break;}
  case 2: { console.log("Andijnga Siz velikda " + velda + " vaqtda Yetib borasiz"); break;}
  case 3: { console.log("Andijnga Siz moshinada " + Math.round(moshinada) + " vaqtda Yetib borasiz"); break;}
  case 4: { console.log("Andijnga Siz poyezdda " + Math.ceil(poyezdda) + " vaqtda Yetib borasiz"); break;}
  case 5: { console.log("Andijnga Siz samalyotda " + samalyotda + " vaqtda Yetib borasiz"); break;}
  default: { console.log("Xato raqam kiritdingiz!");}
}