let cars = ["BMW", "Mercades", "Gentra", "Ford", "Lombarghini", "Mclaren", "Tesla", "Nissan"];
let inputs_car = prompt("Mashina nomini bosh hariflarini katta harfda yozib kiriting: ");

if (cars.includes(inputs_car) === true) {
  console.log(inputs_car + " bu mashina ro'yxatda bor");
} else {
  cars.unshift(inputs_car);
  console.log(inputs_car + " Qo'shildi \nSizda " + cars + " mashinalar yig`ilmoqda👍");
}