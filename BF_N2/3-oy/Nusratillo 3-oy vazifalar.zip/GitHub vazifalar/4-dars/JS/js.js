alert("About ME!")
let fname = prompt("First name: ");
let lname = prompt("Last name: ");

let age = prompt("Age: ");
let profession = prompt("Kasbingiz nima: ");

let about = prompt("O`qiysizmi yoki ishlaysizmi: ")
let phonNumber = prompt("Telefon raqamingizni kiriting");

let email = prompt("Emailingizni kiriting");
let country = prompt("Where you live:");

let address = prompt("Yashash manzilingizni kiriting");
let language = prompt("Qaysi tillarni bilasiz 'vergul bilan ajratib yozing'");

console.log(
    "My first name is " + fname +
    ". My last name is " + lname +
    
    ". My age " + age +
    ". Kasbim " + profession + 

    ". " +  about + 
    ". Tel : " +  phonNumber + 

    ". Emayil manzilim " + email + 
    ". My country " + country +

    ". My address " +  address + 
    ". Shu tillarni bilaman " +  language + "😎"
);