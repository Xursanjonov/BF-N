// 1-usul
let interests = ['sport', 'cars', 'song', 'IT'];
let interesting = ['football', 'basketball', 'Lamborghini sport car', 'C/C++', 'Python'];

let child = {
    fname: 'Komil',
    lname: 'Temirov',
    age: 14,
    country: "AQSh",
    state: "New-York",
    district: "Chinatown",
    street: "Bayard st",
    school: "NEMT+m school",
    hobby: interests,
    what_They_Know: interesting,
    favorite_food: ["lavash", 'hamburger']
}

// 2-usul

/*
let child = {
    fullname: 'Komil Temirov',
    age: 14,
    country: "AQSh",
    state: "New-York",
    district: "Chinatown",
    street: "Bayard st",
    school: "NEMT+m school",
    hobby: ['sport', 'cars', 'song', 'IT'],
    what_They_Know: ['football', 'basketball', 'Lamborghini sport car', 'C/C++', 'Python'],
    favorite_food: ["lavash", 'hamburger']
}

*/

console.log(child)