// let a = +prompt("Qaysi sondan bo`shlasin: ");
let a = 17;

// let b = +prompt("Qaysi songacha bo`lsin: ");
let b = 25;

// a = min and b = max

let n = Math.floor(Math.random() * (b - a + 1))+a;

console.log(n);