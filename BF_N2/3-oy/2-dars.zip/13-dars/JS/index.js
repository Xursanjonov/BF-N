// 03.11.2023-y
// JS mavzu: 