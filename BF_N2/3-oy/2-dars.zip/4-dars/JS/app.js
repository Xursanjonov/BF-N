// alert("Hammaga Salom!") // single line
// confirm("JS ni o`rganishga tayyormisiz!");
// prompt("Parol kiriting: ");
console.log('Hammaga Salom');
console.log("Salom N2");

// Bir qatorli kamentariya
/* Ko`p qatorli kamentariya */

// CONST
const max_Live = 5;
// CONST ga tenglangan  qiymat o`zgarmaydi
console.log(max_Live)
// LET
let age = 19;
// LET ga tenglangan  qiymat o`zgarmaydi
console.log(age)
age = 20;
console.log(age)

let fname = prompt("Ismingizni kiriting: ");
let lname = prompt("Familiyangizni kiriting: ");
console.log(fname + ' ' + lname)
let ages = prompt("Yoshingizni kiriting: "), a = "yosh";
console.log(ages, a)

// DAta type

// Primitive

// String
// let name = 'Eshmat \n o`zbekiston'

// Number
// let age = 19; let price = 999.99

// Boolean => true or false
// let isGood = true; let isBad = false

// Undefined => aniqlanmagan
// let motto = undefined
// console.log(motto);

// Null => Bo`sh
// let hamyon = null

// REference => Bog`liqlik

// Array => To`plam
// let frontend = ['HTML', 'CSS', 'SASS', 'BS', 'AOS', 'TW', 'JS']
// console.log(frontend);

// Object
let person = {
    name: 'Eshmat',
    email: 'eshmat@gmail.com',
    age: 32,
    isMArried: true,
    isLearning: true,
    skills: ['Js', 'React.js', 'Viue.js'],
};

console.log(person);


let lName = 'Toshmatov';
// console.log("to`liq ismi Eshmat " +  lName + "yosh")

