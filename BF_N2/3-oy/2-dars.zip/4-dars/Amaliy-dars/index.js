// Amaliyot 1-dars

// let student = {
//     name: "Komil",
//     familiyasi: "Sultonov",
//     age: 20,
//     adress: "Toshkent"
// }

// console.log(student)

// let person = {
//     name: "Akmal",
//     familiyasi: "Temirov",
//     age: 20,
//     address: "London"
// }

// var a = 5, b = 10;

// for (let i = 0; a = b; b-=1) {
//   i = i + b;
//   console.log(i, '\n')
// }

let a = 8;

console.log('P (Perimetri) =', 4*a)
console.log('S (Yuzasi) =', a*a)
console.log('A-B tomonlar =', a+a)
console.log('A-D tomonlar =', a+a)
console.log('B-C tomonlar =', a+a)
console.log('C-D tomonlar =', a+a)
console.log('D-B tomonlar =', a+a)