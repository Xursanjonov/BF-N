/*
let music = new Audio("/audio/music.mp4");
music.paused;
music.duration;
music.currentTime;
music.volume;
music.play();
music.pause();
music.onend = () => {};
music.onloadeddate = () => {};
*/

