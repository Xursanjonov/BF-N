/* 
Uyga vazifa
1) lbs to kg (1lbs = 0.453592kg)
2) BMI (height, weight) => height * height / weight (https://austingynecomastiacenter.com/assets/img/blog/BMI-Chart-Simple.png)
3) random number guesser with 5chances
4) translate function => input english => ru (ruschada), uz (o'zbecha)
*/

// 1) lbs to kg (1lbs = 0.453592kg)

