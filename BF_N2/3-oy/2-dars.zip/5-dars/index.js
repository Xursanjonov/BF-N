// Type conversion
// string, boolean => number
// NaN => Not a Number
// let n = "12345"
// Number() constructor function
// console.log(parseInt(n))
// console.log(parseFloat(n))
// console.log(+n)
// console.log(-n)
// console.log(n * 1)
// console.log(n / 1)
// console.log(n - 1)
// console.log(n + 1)

// Number => Strinng
let s = 123.45;

// String() constructor function
// console.log(String(s))
// console.log(s + "")

// Number => String
// console.log(s.toString())
// console.log(s.toFixed(5))
