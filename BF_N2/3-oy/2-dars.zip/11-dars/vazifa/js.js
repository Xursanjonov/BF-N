/* 1-masala
Svitafor

ul -> class => circles
li -> class => circle1

Colors

li => class -> red
li => class -> gold
li => class -> green

*/

/* 2-masala



*/