let images = [
    "/images/img 1.jpg",
    "/images/img 2.jpg",
    "/images/img 3.png",
    "/images/img 4.jpg",
    "/images/img 5.webp",
    "/images/img 6.jpg",
    "/images/img 7.webp",
    "/images/img 8.jpg",
];

let imagesDiv = document.createElement("div");
let backDiv = document.createElement("div");
let img = document.createElement("img");

